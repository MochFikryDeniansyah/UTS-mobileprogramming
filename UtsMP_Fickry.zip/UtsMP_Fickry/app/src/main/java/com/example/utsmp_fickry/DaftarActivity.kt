package com.example.utsmp_fickry

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class DaftarActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_daftar)

        val login = findViewById<TextView>(R.id.textlogin)
        login.setOnClickListener({
            Intent(this, LoginActivity::class.java).also {
                startActivity(it)
            }
        })

        val buttonDaftar = findViewById<Button>(R.id.btn_daftar)
        buttonDaftar.setOnClickListener({
            Toast.makeText(this,"Yeay...berhasil daftar", Toast.LENGTH_SHORT).show();
            Log.d("Daftar","klik");
            Intent(this, ProfileActivity::class.java).also {
                startActivity(it)
            }
        })


    }
}
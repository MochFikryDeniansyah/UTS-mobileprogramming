package com.example.utsmp_fickry

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val daftar = findViewById<TextView>(R.id.textdaftar)
        daftar.setOnClickListener({
            Intent(this, DaftarActivity::class.java).also {
                startActivity(it)
            }
        })

        val buttonLogin = findViewById<Button>(R.id.btn_login)
        buttonLogin.setOnClickListener({
            Toast.makeText(this,"Yeay...login berhasil", Toast.LENGTH_SHORT).show();
            Log.d("Login","klik");
            Intent(this, ProfileActivity::class.java).also {
                startActivity(it)
            }
        })
    }
}